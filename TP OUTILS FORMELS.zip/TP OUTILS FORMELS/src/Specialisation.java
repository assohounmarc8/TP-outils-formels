public class Specialisation {
    private boolean carteValide;
    private boolean codeValide;

    public Specialisation(boolean carteValide, boolean codeValide) {
        this.carteValide = carteValide;
        this.codeValide = codeValide;
    }

    public boolean isCarteVerif() {
        return carteValide;
    }

    public boolean isCodeVerif() {
        return codeValide;
    }
}
