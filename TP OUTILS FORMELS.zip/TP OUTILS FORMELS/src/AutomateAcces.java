public class AutomateAcces {
    // États possibles de l'automate
    public enum Etats {
        AccesAccorde, AccesRefuse, Alarme
    }

    private Etats etatActuel;

    public AutomateAcces() {
        etatActuel = Etats.AccesRefuse; // L'accès est initialement refusé
    }

    public Etats getEtat() {
        return etatActuel;
    }

    public void setEtat(Etats etat) {
        this.etatActuel = etat;
    }

    // Vérification de la validité de la carte
    public void VerifCarte(boolean carteValide) {
        if (carteValide) {
            System.out.println("Carte valide");
        } else {
            System.out.println("Carte invalide");
        }
    }

    // Vérification du code
    public void VerifCode(boolean codeValide) {
        if (codeValide) {
            System.out.println("Code correct");
        } else {
            System.out.println("Code incorrect");
        }
    }
}
